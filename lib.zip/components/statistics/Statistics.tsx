"use client";

import { motion } from "framer-motion";
import { statistics } from "@/constants/portfolio";

const Statistics = () => {
  return (
    <section id="statistics" className="relative overflow-hidden px-6 py-24">
      <div className="mx-auto max-w-6xl text-center">
        <p className="text-sm uppercase tracking-[0.35em] text-violet-400">
          Estatísticas
        </p>
        <h2 className="mt-4 text-3xl font-bold text-white md:text-4xl">
          Resultados que reforçam meu compromisso
        </h2>
      </div>

      <div className="mx-auto mt-14 grid max-w-6xl gap-6 sm:grid-cols-2 xl:grid-cols-4">
        {statistics.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.08 }}
            viewport={{ once: true, margin: "-100px" }}
            className="rounded-3xl border border-white/10 bg-neutral-900 p-8 text-center shadow-lg shadow-violet-500/5"
          >
            <p className="text-5xl font-semibold text-white">{item.value}</p>
            <p className="mt-4 text-sm uppercase tracking-[0.2em] text-zinc-400">
              {item.label}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Statistics;
