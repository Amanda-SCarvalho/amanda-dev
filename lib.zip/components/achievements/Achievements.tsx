"use client";

import { motion } from "framer-motion";
import { achievements } from "@/constants/portfolio";

const Achievements = () => {
  return (
    <section id="conquistas" className="relative overflow-hidden px-6 py-24">
      <div className="mx-auto max-w-6xl text-center">
        <p className="text-sm uppercase tracking-[0.35em] text-violet-400">
          Conquistas
        </p>
        <h2 className="mt-4 text-3xl font-bold text-white md:text-4xl">
          Medidas que mostram dedicação
        </h2>
      </div>

      <div className="mx-auto mt-14 max-w-4xl">
        {achievements.map((achievement, index) => (
          <motion.div
            key={achievement.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.08 }}
            viewport={{ once: true, margin: "-100px" }}
            className="rounded-3xl border border-white/10 bg-neutral-900 p-10 shadow-xl shadow-violet-500/5"
          >
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="size-20 grid place-items-center rounded-full bg-violet-500/10 text-4xl">
                {achievement.emoji}
              </div>
              <div>
                <p className="text-sm uppercase tracking-[0.2em] text-violet-300">
                  {achievement.year}
                </p>
                <h3 className="mt-3 text-2xl font-semibold text-white">
                  {achievement.title}
                </h3>
                <p className="mt-3 text-base leading-relaxed text-zinc-400">
                  {achievement.description}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Achievements;
