﻿"use client";

import type { ReactNode } from "react";
import DotPattern from "../ui/dot-pattern";
import Image from "next/image";
import { motion } from "framer-motion";
import { aboutParagraphs, profileHighlights } from "@/constants/portfolio";

/**
 * Uma "linha" do arquivo: número na esquerda (estilo editor de código),
 * conteúdo à direita. A numeração aqui não é decorativa — ela reflete
 * linhas reais do "arquivo" que estamos renderizando.
 */
const Line = ({
  n,
  children,
  className = "",
}: {
  n: number;
  children: ReactNode;
  className?: string;
}) => (
  <div className={`flex gap-4 md:gap-6 ${className}`}>
    <span className="w-6 shrink-0 select-none pt-[2px] text-right font-mono text-[11px] leading-relaxed text-zinc-700 md:w-8 md:text-xs">
      {n}
    </span>
    <div className="min-w-0 flex-1 leading-relaxed">{children}</div>
  </div>
);

const About = () => {
  let ln = 0;
  const next = () => ++ln;

  return (
    <section id="sobre" className="relative overflow-hidden px-6 py-24">
      <DotPattern
        width={20}
        height={20}
        cx={1}
        cy={1}
        cr={1}
        className="dot-pattern pointer-events-none absolute inset-0 -z-10 opacity-20"
      />

      <motion.div
        className="mx-auto max-w-3xl overflow-hidden rounded-xl border border-white/10 bg-neutral-950/90 shadow-2xl shadow-black/40"
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true, margin: "-100px" }}
      >
        {/* barra de aba, tipo editor de código */}
        <div className="flex items-center gap-3 border-b border-white/10 bg-neutral-900/70 px-4 py-3">
          <div className="flex gap-1.5">
            <span className="size-2.5 rounded-full bg-zinc-700" />
            <span className="size-2.5 rounded-full bg-zinc-700" />
            <span className="size-2.5 rounded-full bg-zinc-700" />
          </div>
          <span className="font-mono text-xs text-zinc-500">
            sobre / <span className="text-zinc-300">README.md</span>
          </span>
        </div>

        {/* corpo do "arquivo" */}
        <div className="space-y-3 px-5 py-8 text-sm text-zinc-300 sm:px-8 md:text-[15px]">
          {/* frontmatter */}
          <Line n={next()} className="font-mono text-zinc-600">
            ---
          </Line>
          <Line n={next()} className="font-mono">
            <span className="text-violet-400/80">role: </span>
            <span className="text-zinc-300">Dev Frontend / Fullstack</span>
          </Line>
          <Line n={next()} className="font-mono">
            <span className="text-violet-400/80">foco: </span>
            <span className="text-zinc-300">UX/UI · Estudante de ADS</span>
          </Line>
          <Line n={next()} className="font-mono">
            <span className="text-violet-400/80">local: </span>
            <span className="text-zinc-300">São Paulo, Brasil</span>
          </Line>
          <Line n={next()} className="font-mono text-zinc-600">
            ---
          </Line>
          <Line n={next()}>&nbsp;</Line>

          {/* título */}
          <Line n={next()}>
            <span className="font-mono text-zinc-600">#&nbsp;</span>
            <span className="text-2xl font-bold text-white md:text-3xl">
              Amanda Carvalho
            </span>
          </Line>
          <Line n={next()}>&nbsp;</Line>

          {/* headline / tagline como blockquote */}
          <Line n={next()} className="border-l-2 border-violet-400/40 pl-4">
            <span className="font-mono text-zinc-600">&gt;&nbsp;</span>
            <span className="text-lg italic leading-relaxed text-zinc-200 md:text-xl">
              Conectando desenvolvimento web com design centrado no usuário.
            </span>
          </Line>
          <Line n={next()}>&nbsp;</Line>

          {/* imagem embutida como um embed de markdown */}
          <Line n={next()} className="font-mono text-xs text-zinc-600">
            ![Amanda Carvalho](profile.jpeg)
          </Line>
          <Line n={next()}>
            <div className="relative size-40 overflow-hidden rounded-lg border border-white/10 sm:size-48">
              <Image
                src="/profile.jpeg"
                alt="Amanda Santos de Carvalho"
                fill
                className="object-cover"
                priority
              />
            </div>
          </Line>
          <Line n={next()}>&nbsp;</Line>

          {/* parágrafos */}
          {aboutParagraphs.map((paragraph, index) => (
            <Line key={index} n={next()} className="text-zinc-300">
              {paragraph}
            </Line>
          ))}
          <Line n={next()}>&nbsp;</Line>

          {/* subtítulo */}
          <Line n={next()}>
            <span className="font-mono text-zinc-600">##&nbsp;</span>
            <span className="text-lg font-semibold text-white">
              Como eu trabalho
            </span>
          </Line>
          <Line n={next()}>&nbsp;</Line>

          {/* highlights como lista markdown */}
          {profileHighlights.map((highlight) => (
            <Line key={highlight.id} n={next()}>
              <span className="font-mono text-violet-400/80">- </span>
              <span className="font-semibold text-white">
                {highlight.title}
              </span>
              <span className="text-zinc-500"> — </span>
              <span className="text-zinc-400">{highlight.description}</span>
            </Line>
          ))}
          <Line n={next()}>&nbsp;</Line>

          {/* cursor piscando no fim do arquivo */}
          <Line n={next()} className="font-mono text-zinc-600">
            <motion.span
              className="inline-block h-[1em] w-[7px] translate-y-[2px] bg-violet-400/80"
              animate={{ opacity: [1, 1, 0, 0] }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
          </Line>
        </div>
      </motion.div>
    </section>
  );
};

export default About;