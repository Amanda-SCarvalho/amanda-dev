"use client";

import DotPattern from "../ui/dot-pattern";
import TechTag from "./TechTag";
import { motion } from "framer-motion";
import { skillCategories } from "@/constants/portfolio";

const Techs = () => {
  const sectionVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.12,
        duration: 0.5,
        ease: "easeOut",
      },
    }),
  };

  return (
    <section id="skills" className="relative overflow-hidden px-6 py-28">
      <motion.div
        className="pointer-events-none absolute left-1/2 top-1/2 -z-10 size-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-500/10 blur-3xl"
        animate={{
          scale: [1, 1.05, 1],
          opacity: [0.1, 0.18, 0.1],
        }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="mx-auto flex max-w-6xl flex-col gap-16">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
        >
          <p className="text-sm uppercase tracking-[0.35em] text-violet-400">
            Habilidades técnicas
          </p>
          <h2 className="mt-4 text-3xl font-bold text-white md:text-4xl">
            Tecnologias organizadas por área.
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg leading-relaxed text-zinc-400">
            Uma visão clara das ferramentas que uso para criar produtos digitais
            completos, desde front-end até documentação e dados.
          </p>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              className="rounded-3xl border border-white/10 bg-neutral-900/80 p-8 shadow-xl shadow-violet-500/5"
              initial="hidden"
              whileInView="visible"
              custom={index}
              variants={sectionVariants}
              viewport={{ once: true, margin: "-100px" }}
            >
              <h3 className="text-xl font-semibold text-white">
                {category.title}
              </h3>
              <div className="mt-6 flex flex-wrap gap-3">
                {category.items.map((item) => (
                  <TechTag key={item} title={item} />
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <DotPattern
        width={20}
        height={20}
        cx={1}
        cy={1}
        cr={1}
        className="dot-pattern opacity-30"
      />
    </section>
  );
};

export default Techs;
