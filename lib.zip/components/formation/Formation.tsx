"use client";

import { motion } from "framer-motion";
import { formation } from "@/constants/portfolio";

const Formation = () => {
  return (
    <section id="formation" className="relative overflow-hidden px-6 py-24">
      <div className="mx-auto max-w-6xl text-center">
        <p className="text-sm uppercase tracking-[0.35em] text-violet-400">
          Formação
        </p>
        <h2 className="mt-4 text-3xl font-bold text-white md:text-4xl">
          Jornada acadêmica e técnica
        </h2>
      </div>

      <div className="mx-auto mt-14 grid max-w-6xl gap-6 sm:grid-cols-2">
        {formation.map((item, index) => (
          <motion.div
            key={`${item.institution}-${item.period}`}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.08 }}
            viewport={{ once: true, margin: "-100px" }}
            className="rounded-3xl border border-white/10 bg-neutral-900 p-8 shadow-sm shadow-violet-500/5"
          >
            <p className="text-sm uppercase tracking-[0.2em] text-violet-300">
              {item.period}
            </p>
            <h3 className="mt-4 text-xl font-semibold text-white">
              {item.institution}
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-zinc-400">
              {item.degree}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Formation;
