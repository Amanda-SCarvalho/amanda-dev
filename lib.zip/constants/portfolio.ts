export const resumeLink =
  "/Resumo-Amanda-Carvalho-Portuguese-Completo.pdf%20(3).pdf";

export const aboutParagraphs = [
  "Sou estudante de Análise e Desenvolvimento de Sistemas na FATEC Ferraz de Vasconcelos e formada tecnicamente em Desenvolvimento de Sistemas pela ETEC Cidade Tiradentes.",
  "Tenho experiência no desenvolvimento de aplicações web, integração com bancos de dados relacionais, documentação técnica e criação de interfaces centradas no usuário. Minha abordagem une tecnologia, design e usabilidade para entregar produtos com foco em valor real.",
  "Busco minha primeira oportunidade profissional para transformar conhecimento em impacto real. Sou proativa, organizada, comunicativa e gosto de trabalhar em equipe enquanto sigo evoluindo como desenvolvedora e designer.",
];

export const profileHighlights = [
  {
    id: "1",
    title: "Aprendizado rápido",
    description:
      "Adapto-me com facilidade às novas tecnologias e frameworks para entregar soluções atualizadas.",
  },
  {
    id: "2",
    title: "Trabalho em equipe",
    description:
      "Colaboro com clareza e empatia, mantendo a comunicação alinhada em projetos multidisciplinares.",
  },
  {
    id: "3",
    title: "Foco em UX e documentação",
    description:
      "Produzo protótipos, pesquisas de usuário e documentação técnica para apoiar decisões de produto.",
  },
];

export const skillCategories = [
  {
    title: "Frontend",
    items: [
      "HTML5",
      "CSS3",
      "JavaScript",
      "TypeScript",
      "React",
      "Next.js",
      "Tailwind CSS",
    ],
  },
  {
    title: "Backend",
    items: ["Java", "Python"],
  },
  {
    title: "Banco de Dados",
    items: ["SQL", "MySQL", "SQL Server", "Prisma ORM"],
  },
  {
    title: "UI/UX",
    items: ["Figma", "Canva"],
  },
  {
    title: "Ferramentas",
    items: ["Git", "GitHub", "VS Code", "Power BI", "AutoCAD"],
  },
  {
    title: "Documentação",
    items: [
      "Documentação Técnica",
      "Modelagem de Banco",
      "Testes de Software",
      "Análise Técnica",
    ],
  },
];

export const softSkills = [
  "Proatividade",
  "Organização",
  "Trabalho em equipe",
  "Comunicação",
  "Aprendizado contínuo",
  "Pensamento analítico",
  "Resolução de problemas",
  "Adaptabilidade",
];

export const statistics = [
  {
    value: "+10",
    label: "Projetos desenvolvidos",
  },
  {
    value: "5+",
    label: "Tecnologias dominadas",
  },
  {
    value: "100%",
    label: "Comprometimento",
  },
  {
    value: "Sempre",
    label: "Aprendendo novas tecnologias",
  },
];

export const formation = [
  {
    institution: "FATEC Ferraz de Vasconcelos",
    degree: "Tecnólogo em Análise e Desenvolvimento de Sistemas",
    period: "2024 - 2027",
  },
  {
    institution: "Instituto PROA + SENAC",
    degree: "Desenvolvimento Web Java",
    period: "2025 - 2026",
  },
  {
    institution: "ETEC Cidade Tiradentes",
    degree: "Técnico em Desenvolvimento de Sistemas",
    period: "2023 - 2024",
  },
  {
    institution: "ETEC Tiquatira",
    degree: "Ensino Médio Técnico em Química",
    period: "Conclusão 2022",
  },
];

export const certifications = [
  {
    title: "Desenvolvimento Web Java",
    issuer: "Instituto PROA + SENAC",
  },
  {
    title: "Programação em Python para Data Science",
    issuer: "SENAI",
  },
  {
    title: "Introdução à Ciência de Dados",
    issuer: "Cisco Networking Academy",
  },
  {
    title: "Python Módulo Básico",
    issuer: "Huawei Talent Platform",
  },
  {
    title: "Tecnologias de Armazenamento",
    issuer: "Huawei Talent Platform",
  },
  {
    title: "Data Management and Analysis Course",
    issuer: "Huawei Talent Platform",
  },
  {
    title: "Design Thinking Aplicado à Área da Saúde",
    issuer: "FGV",
  },
  {
    title: "Fundamentos de TI Hardware e Software",
    issuer: "Fundação Bradesco",
  },
  {
    title: "Fundamentos de Hardware de Computadores",
    issuer: "Cisco",
  },
  {
    title: "Fundamentos de Design Gráfico",
    issuer: "Fundação Bradesco",
  },
];

export const languages = [
  {
    name: "Português",
    level: "Nativo",
  },
  {
    name: "Inglês",
    level: "Intermediário (Leitura Técnica)",
  },
];

export const achievements = [
  {
    title: "Medalha de Bronze",
    description: "Olimpíada Nacional de Ciências (ONC)",
    year: "2022",
    emoji: "🥉",
  },
];
